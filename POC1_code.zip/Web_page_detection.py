import requests
from bs4 import BeautifulSoup
import os
from urllib.parse import urljoin, urlparse
import numpy as np
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing import image
from sklearn.metrics.pairwise import cosine_similarity
from transformers import pipeline
import joblib

import ssl
import socket
from datetime import datetime
import csv
from urllib.parse import urlparse
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
import warnings

warnings.filterwarnings('ignore')


def get_host_name(url):
    parsed_url = urlparse(url)
    #print(parsed_url.hostname)
    return parsed_url.hostname

def download_ssl_certificate(url, port=443, output_file="certificate.pem"):
    """
    Downloads the SSL certificate from the given hostname and saves it to a file.

    Args:
        hostname (str): The domain name or IP address of the server.
        port (int): The port to connect to (default: 443 for HTTPS).
        output_file (str): Path to save the certificate in PEM format.
    """
    try:
        # Create a default SSL context
        hostname = get_host_name(url)
        context = ssl.create_default_context()

        # Create a TCP connection to the server
        with socket.create_connection((hostname, port), timeout=10) as sock:
            # Wrap the socket with SSL
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                # Get the certificate in DER format
                der_cert = ssock.getpeercert(binary_form=True)

                # Convert DER to PEM
                pem_cert = ssl.DER_cert_to_PEM_cert(der_cert)

                # Save to file
                with open(output_file, "w") as f:
                    f.write(pem_cert)

                print(f"\t\t ✅ Fetched SSL certificate for {hostname} saved to '{output_file} ....'")

                # Optional: print certificate details
                cert_dict = ssock.getpeercert()
                subject = dict(x[0] for x in cert_dict['subject'])
                issuer = dict(x[0] for x in cert_dict['issuer'])
                
                details = {
                    'Subject organization Name': subject.get('organizationName', 'N/A'),
                    'Subject countryName': subject.get('countryName', 'N/A'),
                    'Subject state ProvinceName': subject.get('stateOrProvinceName', 'N/A'),
                    'Subject localityName': subject.get('localityName', 'N/A'),
                    'Issuer Common Name': issuer.get('commonName', 'N/A'),
                    'Issuer organization Name': issuer.get('organizationName', 'N/A'),
                    'Issuer countryName': issuer.get('countryName', 'N/A'),
                    'Brand impersonation' : '0',
                }
                return  details 

    except socket.gaierror:
        print(f"❌ Could not resolve hostname: {hostname}")
    except ssl.SSLError as e:
        print(f"❌ SSL error: {e}")
    except socket.timeout:
        print(f"❌ Connection to {hostname}:{port} timed out")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
    return


def get_intent (title): 
    classifier = pipeline("text-classification", model="Falconsai/intent_classification")
    print ("\t\t Loading BERT model to classify the user behaviour indent for the web page...")
    result = classifier(title)
    print (f"\t\t Expected user behaviour indent classified ::  {result}")
    return result

# 1. Load the pre-trained VGG16 model (without the classification top)
model = VGG16(weights='imagenet', include_top=False, pooling='avg')

def get_image_embedding(img_path):
    # Load and resize image to 224x224 (required by VGG16)
    img = image.load_img(img_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    
    # Extract feature vector
    embedding = model.predict(x)
    return embedding

def compare_image(image1,image2):
# 2. Compare two images
    brand = ''
    emb1 = get_image_embedding(image1)
    emb2 = get_image_embedding(image2)

# 3. Calculate similarity score (0 to 1, where 1 is identical)
    similarity = cosine_similarity(emb1, emb2)
    print(f"\t\t Image Similarity Score: (cosine_similarity) {similarity[0][0]:.4f}")

    if similarity[0][0] > 0.9:
        brand = 'microsoft'
        print("\t\t The images is detected as microsoft logo!")
    else:
        print("\t\t The images is not detected as any brand logo!")
    return brand 

def get_page_info(url):
    # Add headers to mimic a browser request
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        title = ''
        filename = ''
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status() # Raise exception for 4xx/5xx errors
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 1. Get Page Title
        title = soup.title.string if soup.title else "No Title"
        print(f"\n\n\t\t Getting web page infromation {url}")

        print(f"\t\t Page Summary: {title}")
        # 2. Find Favicon
        icon_link = soup.find("link", rel=lambda x: x and 'icon' in x.lower())
        
        if icon_link and icon_link.get('href'):
            favicon_url = icon_link['href']
        else:
            # Fallback to default favicon.ico in root
            favicon_url = urljoin(url, "/favicon.ico")
            
        # Ensure the URL is absolute
        favicon_url = urljoin(url, favicon_url)
        print(f"\t\t Found Favicon URL: {favicon_url}")
        
        # 3. Download Favicon
        filename = download_favicon(favicon_url, headers)
        return title , filename
    except Exception as e:
        print(f"Error: {e}")

def write_to_csv(data_list, filename='ssl_certificates1.csv'):
    """
    Writes a list of certificate details to a CSV file.
    """
    if not data_list:
        print("No data to write to CSV.")
        return

    # Define field names for the CSV header
    fieldnames = data_list[0].keys()

    try:
        with open(filename, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            writer.writeheader()
            for data in data_list:
                writer.writerow(data)
        print(f"Successfully wrote data to {filename}")
    except IOError as e:
        print(f"I/O error writing to file: {e}")



def download_favicon(favicon_url, headers):
    try:
        filename = ''
        favicon_response = requests.get(favicon_url, headers=headers, stream=True)
        if favicon_response.status_code == 200:
            # Create a valid filename from domain
            domain = urlparse(favicon_url).netloc
            filename = f"{domain}_favicon.ico"
            
            with open(filename, 'wb') as f:
                for chunk in favicon_response.iter_content(1024):
                    f.write(chunk)
            print(f"\t\t Successfully downloaded favicon: {filename}")
        else:
            print("Failed to download favicon (status code != 200)")
        return filename 
    except Exception as e:
        print(f"Error downloading favicon: {e}")

def predict (data):
    
    print("\n\t\t Using various classification Model to detect impersonated webpage ... ")
    models = {
    "Logistic Regression": LogisticRegression(max_iter=200, random_state=42),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7),
    "Support Vector Machine": SVC(kernel='linear', random_state=42),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(random_state=42),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
    "Naive Bayes": GaussianNB(),
    }

    for name, model in models.items():
        try:
            model_filename = name +'.joblib'
            loaded_model = joblib.load(model_filename)
            print(f"\n\n\t\t Model successfully loaded from '{model_filename}'")
        except FileNotFoundError:
            print(f"Error: Model file '{model_filename}' not found.")
            print("Please run the optional code above to create a sample model first.")
            exit()

# --- 4. Make a prediction ---
        prediction = loaded_model.predict(data)
        if prediction[0] == 5 : 
            print(f"\t\t Predicted class: Impresonation Detected ! ")
# To get the probabilities for each class
        try:
            probabilities = loaded_model.predict_proba(data)
            print(f"\t\t Impresonation Detection Probabilities: {probabilities}")
        except AttributeError:
            continue
     
# --- 5. Print the results ---
    
    
    

# Example Usage
url = "https://datagivers.com/5c08e6a6fe8e944f636bfae0581qb9d9a3ce.html"
title, filename = get_page_info(url)

if filename != '':
    brand = compare_image('C:\\Users\\baibh\\Downloads\\ms\\favicon_a_eupayfgghqiai7k9sol6lg2.ico',filename)

if title != '':
    intent = get_intent (title)

details = download_ssl_certificate(url, output_file="SSL_cert.pem")

encode_dic = {'N/A': 1, 'R13': 2, "Let's Encrypt": 3, 'US': 4, 'Yes': 5, 'Skyhigh Security': 6, 'Texas': 7, 'Plano': 8, 'GlobalSign RSA OV SSL CA 2018': 9, 'GlobalSign nv-sa': 10, 'BE': 11, 'R12': 12, 'E8': 13, 'WE1': 14, 'Google Trust Services': 15, 'Amazon RSA 2048 M03': 16, 'Amazon': 17, 'Sectigo RSA Domain Validation Secure Server CA': 18, 'Sectigo Limited': 19, 'GB': 20, 'GeoTrust Global TLS RSA4096 SHA256 2022 CA1': 21, 'DigiCert, Inc.': 22, 'ZeroSSL ECC Domain Secure Site CA': 23, 'ZeroSSL': 24, 'AT': 25, 'Amazon RSA 2048 M01': 26, 'E7': 27, 'GlobalSign GCC R6 AlphaSSL CA 2023': 28, 'Sectigo Public Server Authentication CA DV R36': 29, 'Amazon RSA 2048 M02': 30, 'Microsoft Corporation': 31, 'WA': 32, 'Redmond': 33, 'Microsoft Azure RSA TLS Issuing CA 08': 34, 'West Bend Insurance Company': 35, 'Wisconsin': 36, 'West Bend': 37, 'Oracle Corporation': 38, 'California': 39, 'Redwood City': 40, 'DigiCert TLS RSA SHA256 2020 CA1': 41, 'DigiCert Inc': 42, 'Amazon RSA 2048 M04': 43, 'Go Daddy Secure Certificate Authority - G2': 44, 'GoDaddy.com, Inc.': 45, 'WR3': 46, 'Tencent Technology (Shenzhen) Company Limited': 47, 'CN': 48, 'Guangdong Province': 49, 'Shenzhen': 50, 'DigiCert Secure Site OV G2 TLS CN RSA4096 SHA256 2022 CA1': 51, 'WE2': 52, 'WR2': 53, 'RapidSSL TLS RSA CA G1': 54, 'Washington': 55, 'DigiCert Cloud Services CA-1': 56, 'No': 57, 'Microsoft Azure RSA TLS Issuing CA 04': 58, 'Microsoft Azure RSA TLS Issuing CA 07': 59, 'Microsoft TLS G2 RSA CA OCSP 10': 60, 'Microsoft Azure ECC TLS Issuing CA 03': 61, 'Microsoft Azure ECC TLS Issuing CA 07': 62, 'Microsoft Azure RSA TLS Issuing CA 03': 63}

cert_data = []

if details:
    cert_data.append(encode_dic [details['Subject organization Name']])
    cert_data.append(encode_dic [details['Subject countryName']])
    cert_data.append(encode_dic [details['Subject state ProvinceName']])
    cert_data.append(encode_dic [details['Subject localityName']])
    cert_data.append(encode_dic [details['Issuer Common Name']])
    cert_data.append(encode_dic [details['Issuer organization Name']])
    cert_data.append(encode_dic [details['Issuer countryName']])


data = []

data.append(cert_data)

predict(data)

