import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import warnings
import io
import joblib

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

def train_classification_model(filename, feature_cols, target_col):
    """
    Trains and evaluates a classification model using data from a CSV file.

    Args:
        file_path (str): The path to your data file (e.g., 'my_data.csv').
        feature_cols (list): A list of column names to use as features.
        target_col (str): The name of the target column (the class to predict).
    """

    data = pd.read_csv(filename)
    print(f"Loaded '{filename}' successfully!")


    # Optional: Basic data cleaning/preparation (customize as needed)
    # Handle missing values (e.g., fill with median for numeric features)


    # You might need more complex preprocessing for real-world data (e.g., one-hot encoding for categorical data)

    # 2. Define features (X) and target (y)
    X = data[feature_cols]
    y = data[target_col]
    print (X)
    # 3. Split data into training and testing sets (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    print(f"Training set size: {len(X_train)} samples")
    print(f"Testing set size: {len(X_test)} samples")

    # 4. Initialize and train the model
    # We use a Random Forest Classifier as a robust starting point
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    print("\nStarting model training...")
    model.fit(X_train, y_train)
    print("Model training complete.")

    # 5. Evaluate the model
    print (X_test)
    y_pred = model.predict(X_test)
    #accuracy = accuracy_score(y_test, y_pred)

    #print(f"\nModel Accuracy on Test Data: {accuracy:.2f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    filename = 'random_forest_model.joblib'
    joblib.dump(model, filename)
    print(f"Model successfully saved as '{filename}'\n")

    return model

trained_model = train_classification_model(
     filename= 'C:\\Users\\baibh\\Downloads\\encoded_output.csv',
     feature_cols=['Subject organization Name','Subject countryName' ,'Subject state ProvinceName' ,'Subject localityName','Issuer Common Name','Issuer organization Name','Issuer countryName'],
     target_col='Brand impersonation'
)