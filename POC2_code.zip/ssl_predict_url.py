"""
Usage:
    py -3.12 ssl_predict_url.py <url>

Example:
    py -3.12 ssl_predict_url.py https://outlook.com
    py -3.12 ssl_predict_url.py fun-creators.net
"""

import ssl
import socket
import sys
import joblib
import pandas as pd
from urllib.parse import urlparse

MODEL_PATH = 'ssl_classifier_model.joblib'

BRAND_KEYWORDS = ['microsoft', 'office', 'azure', 'outlook', 'onedrive',
                  'sharepoint', 'teams', 'msn', 'hotmail', 'live', 'bing',
                  'windows', 'xbox', 'skype', 'linkedin']
FREE_CA_ISSUERS = ["let's encrypt", 'zerossl', 'buypass']
MS_DOMAINS = ['microsoft.com', 'microsoftonline.com', 'live.com',
              'msn.com', 'bing.com', 'azure.com', 'github.io',
              'azureedge.net', 'windows.net']


def fetch_cert(hostname: str, port: int = 443, timeout: int = 10) -> dict:
    """Fetch SSL certificate fields from a live host."""
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                return ssock.getpeercert()
    except ssl.SSLCertVerificationError:
        # Retry without verification so we can still classify the cert
        ctx_noverify = ssl.create_default_context()
        ctx_noverify.check_hostname = False
        ctx_noverify.verify_mode = ssl.CERT_NONE
        with socket.create_connection((hostname, port), timeout=timeout) as sock:
            with ctx_noverify.wrap_socket(sock, server_hostname=hostname) as ssock:
                return ssock.getpeercert(binary_form=False)


def parse_cert_field(cert_tuples, key: str) -> str:
    """Extract a named field from cert subject/issuer tuple-of-tuples."""
    for rdn in cert_tuples:
        for attr, val in rdn:
            if attr == key:
                return val
    return 'N/A'


def cert_to_row(cert: dict) -> pd.DataFrame:
    """Convert a parsed SSL cert dict into a single-row DataFrame matching training schema."""
    subject = cert.get('subject', ())
    issuer  = cert.get('issuer', ())

    return pd.DataFrame([{
        'Subject Common Name':        parse_cert_field(subject, 'commonName'),
        'Subject organization Name':  parse_cert_field(subject, 'organizationName'),
        'Subject countryName':        parse_cert_field(subject, 'countryName'),
        'Subject state ProvinceName': parse_cert_field(subject, 'stateOrProvinceName'),
        'Subject localityName':       parse_cert_field(subject, 'localityName'),
        'Issuer Common Name':         parse_cert_field(issuer,  'commonName'),
        'Issuer organization Name':   parse_cert_field(issuer,  'organizationName'),
        'Issuer countryName':         parse_cert_field(issuer,  'countryName'),
    }])


def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    feat = pd.DataFrame(index=df.index)

    scn = df['Subject Common Name'].fillna('').str.lower()
    feat['domain_len']       = scn.str.len()
    feat['is_wildcard']      = scn.str.startswith('*').astype(int)
    feat['subdomain_depth']  = scn.str.count(r'\.')
    feat['has_hyphen']       = scn.str.contains('-').astype(int)
    feat['has_digits']       = scn.str.contains(r'\d').astype(int)
    feat['has_brand_keyword'] = scn.apply(lambda x: int(any(kw in x for kw in BRAND_KEYWORDS)))
    feat['tld']              = scn.apply(lambda x: x.rsplit('.', 1)[-1] if '.' in x else 'none')
    feat['is_ms_domain']     = scn.apply(lambda x: int(any(x.endswith(d) for d in MS_DOMAINS)))

    sorg = df['Subject organization Name'].fillna('N/A').str.strip()
    feat['has_subject_org']   = (sorg != 'N/A').astype(int)
    feat['subject_org_is_ms'] = sorg.str.lower().str.contains('microsoft').astype(int)

    feat['has_state']    = (df['Subject state ProvinceName'].fillna('N/A').str.strip() != 'N/A').astype(int)
    feat['has_locality'] = (df['Subject localityName'].fillna('N/A').str.strip() != 'N/A').astype(int)

    feat['subject_country'] = df['Subject countryName'].fillna('N/A').str.strip()

    issuer_cn  = df['Issuer Common Name'].fillna('').str.lower()
    issuer_org = df['Issuer organization Name'].fillna('').str.lower()

    feat['issuer_is_free_ca']  = issuer_org.apply(lambda x: int(any(ca in x for ca in FREE_CA_ISSUERS)))
    feat['issuer_is_ms']       = issuer_org.str.contains('microsoft').astype(int)
    feat['issuer_is_digicert'] = issuer_org.str.contains('digicert').astype(int)
    feat['issuer_is_google']   = issuer_org.str.contains('google').astype(int)
    feat['issuer_is_amazon']   = issuer_org.str.contains('amazon').astype(int)
    feat['issuer_is_sectigo']  = issuer_org.str.contains('sectigo').astype(int)
    feat['issuer_cn']          = issuer_cn
    feat['issuer_country']     = df['Issuer countryName'].fillna('N/A').str.strip()

    return feat


def encode_features(feat: pd.DataFrame, encoders: dict, cat_cols: list) -> pd.DataFrame:
    feat = feat.copy()
    for col in cat_cols:
        le = encoders[col]
        val = str(feat[col].iloc[0])
        feat[col] = le.transform([val])[0] if val in le.classes_ else -1
    return feat


def classify_url(url: str) -> None:
    # Normalise URL — accept bare hostnames too
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    parsed   = urlparse(url)
    hostname = parsed.hostname
    port     = parsed.port or 443

    print(f"\nTarget : {hostname}:{port}")
    print("-" * 50)

    # Fetch certificate
    print("Fetching SSL certificate...")
    try:
        cert = fetch_cert(hostname, port)
    except Exception as e:
        print(f"ERROR: Could not retrieve certificate — {e}")
        sys.exit(1)

    # Show raw cert fields
    row = cert_to_row(cert)
    print("\nCertificate fields:")
    for col, val in row.iloc[0].items():
        print(f"  {col:<32} {val}")

    # Load model
    saved       = joblib.load(MODEL_PATH)
    model       = saved['model']
    encoders    = saved['encoders']
    cat_cols    = ['tld', 'subject_country', 'issuer_cn', 'issuer_country']

    # Feature engineering + encoding
    feat = extract_features(row)
    feat = encode_features(feat, encoders, cat_cols)
    feat = feat[saved['feature_cols']]  # ensure column order matches training

    # Predict
    prob  = model.predict_proba(feat)[0][1]
    label = int(prob >= 0.5)

    print("\n" + "=" * 50)
    print(f"  Result     : {'IMPERSONATION' if label == 1 else 'LEGITIMATE'}")
    print(f"  Score      : {prob:.1%} impersonation probability")
    print("=" * 50)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: py -3.12 ssl_predict_url.py <url>")
        print("Example: py -3.12 ssl_predict_url.py https://outlook.com")
        sys.exit(1)
    classify_url(sys.argv[1])
