"""
SSL Certificate Brand Impersonation Classifier
Target: 'Brand impersonation' column (1 = impersonation, 0 = legitimate)
"""

import pandas as pd
import numpy as np
import re
import warnings
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score, make_scorer,
    f1_score, precision_score, recall_score
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------------------
df = pd.read_csv('Mal_ssl_certificates_del.csv')
df.columns = df.columns.str.strip()

print("=" * 60)
print("DATASET OVERVIEW")
print("=" * 60)
print(f"Shape: {df.shape}")
print(f"\nColumns: {list(df.columns)}")
print(f"\nLabel distribution:\n{df['Brand impersonation'].value_counts()}")
print(f"\nClass imbalance ratio: {df['Brand impersonation'].value_counts()[1] / df['Brand impersonation'].value_counts()[0]:.1f}:1 (impersonation:legitimate)")

# ---------------------------------------------------------------------------
# 2. Feature engineering
# ---------------------------------------------------------------------------

BRAND_KEYWORDS = ['microsoft', 'office', 'azure', 'outlook', 'onedrive',
                  'sharepoint', 'teams', 'msn', 'hotmail', 'live', 'bing',
                  'windows', 'xbox', 'skype', 'linkedin']

KNOWN_LEGIT_ISSUERS = ['microsoft', 'digicert']
FREE_CA_ISSUERS = ["let's encrypt", 'zerossl', 'buypass']


def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    feat = pd.DataFrame(index=df.index)

    # --- Subject Common Name features ---
    scn = df['Subject Common Name'].fillna('').str.lower()

    feat['domain_len'] = scn.str.len()
    feat['is_wildcard'] = scn.str.startswith('*').astype(int)
    feat['subdomain_depth'] = scn.str.count(r'\.')
    feat['has_hyphen'] = scn.str.contains('-').astype(int)
    feat['has_digits'] = scn.str.contains(r'\d').astype(int)
    feat['has_brand_keyword'] = scn.apply(
        lambda x: int(any(kw in x for kw in BRAND_KEYWORDS))
    )
    # TLD (last extension)
    feat['tld'] = scn.apply(lambda x: x.rsplit('.', 1)[-1] if '.' in x else 'none')

    # Microsoft's own domains (known legitimate patterns)
    MS_DOMAINS = ['microsoft.com', 'microsoftonline.com', 'live.com',
                  'msn.com', 'bing.com', 'azure.com', 'github.io',
                  'azureedge.net', 'windows.net']
    feat['is_ms_domain'] = scn.apply(
        lambda x: int(any(x.endswith(d) for d in MS_DOMAINS))
    )

    # --- Subject organization features ---
    sorg = df['Subject organization Name'].fillna('N/A').str.strip()
    feat['has_subject_org'] = (sorg != 'N/A').astype(int)
    feat['subject_org_is_ms'] = sorg.str.lower().str.contains('microsoft').astype(int)

    # --- Subject location features ---
    feat['has_state'] = (df['Subject state ProvinceName'].fillna('N/A').str.strip() != 'N/A').astype(int)
    feat['has_locality'] = (df['Subject localityName'].fillna('N/A').str.strip() != 'N/A').astype(int)

    # Subject country (encoded)
    feat['subject_country'] = df['Subject countryName'].fillna('N/A').str.strip()

    # --- Issuer features ---
    issuer_cn = df['Issuer Common Name'].fillna('').str.lower()
    issuer_org = df['Issuer organization Name'].fillna('').str.lower()

    feat['issuer_is_free_ca'] = issuer_org.apply(
        lambda x: int(any(ca in x for ca in FREE_CA_ISSUERS))
    )
    feat['issuer_is_ms'] = issuer_org.str.contains('microsoft').astype(int)
    feat['issuer_is_digicert'] = issuer_org.str.contains('digicert').astype(int)
    feat['issuer_is_google'] = issuer_org.str.contains('google').astype(int)
    feat['issuer_is_amazon'] = issuer_org.str.contains('amazon').astype(int)
    feat['issuer_is_sectigo'] = issuer_org.str.contains('sectigo').astype(int)
    feat['issuer_cn'] = issuer_cn
    feat['issuer_country'] = df['Issuer countryName'].fillna('N/A').str.strip()

    return feat


raw_features = extract_features(df)

# Encode categorical columns
cat_cols = ['tld', 'subject_country', 'issuer_cn', 'issuer_country']
encoders = {}
for col in cat_cols:
    le = LabelEncoder()
    raw_features[col] = le.fit_transform(raw_features[col].astype(str))
    encoders[col] = le

X = raw_features.copy()
y = df['Brand impersonation'].astype(int)

print(f"\n{'=' * 60}")
print("ENGINEERED FEATURES")
print("=" * 60)
print(f"Total features: {X.shape[1]}")
print(f"Feature names: {list(X.columns)}")

# ---------------------------------------------------------------------------
# 3. Models — all use class_weight='balanced' due to severe imbalance
# ---------------------------------------------------------------------------
models = {
    'Random Forest': RandomForestClassifier(
        n_estimators=200,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    ),
    'Gradient Boosting': GradientBoostingClassifier(
        n_estimators=200,
        max_depth=4,
        learning_rate=0.05,
        random_state=42,
    ),
    'Logistic Regression': Pipeline([
        ('scaler', StandardScaler()),
        ('clf', LogisticRegression(
            class_weight='balanced',
            max_iter=1000,
            random_state=42
        ))
    ]),
}

# Gradient Boosting doesn't support class_weight natively;
# compensate via sample_weight in scoring or use scale_pos_weight equivalent
# We'll handle it by passing sample_weight in cross-validation manually.

scoring = {
    'f1': make_scorer(f1_score),
    'precision': make_scorer(precision_score),
    'recall': make_scorer(recall_score),
    'roc_auc': 'roc_auc',
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

print(f"\n{'=' * 60}")
print("5-FOLD CROSS-VALIDATION RESULTS")
print("=" * 60)

cv_results = {}
for name, model in models.items():
    scores = cross_validate(model, X, y, cv=cv, scoring=scoring, n_jobs=-1)
    cv_results[name] = scores
    print(f"\n{name}:")
    print(f"  F1 (macro avg):  {scores['test_f1'].mean():.3f} ± {scores['test_f1'].std():.3f}")
    print(f"  Precision:       {scores['test_precision'].mean():.3f} ± {scores['test_precision'].std():.3f}")
    print(f"  Recall:          {scores['test_recall'].mean():.3f} ± {scores['test_recall'].std():.3f}")
    print(f"  ROC-AUC:         {scores['test_roc_auc'].mean():.3f} ± {scores['test_roc_auc'].std():.3f}")

# ---------------------------------------------------------------------------
# 4. Train final Random Forest on full data & show feature importance
# ---------------------------------------------------------------------------
print(f"\n{'=' * 60}")
print("FINAL MODEL: Random Forest (trained on full dataset)")
print("=" * 60)

best_model = RandomForestClassifier(
    n_estimators=200,
    class_weight='balanced',
    random_state=42,
    n_jobs=-1
)
best_model.fit(X, y)

importances = pd.Series(best_model.feature_importances_, index=X.columns)
importances = importances.sort_values(ascending=False)
print("\nTop 15 Feature Importances:")
print(importances.head(15).to_string())

# ---------------------------------------------------------------------------
# 5. Save model + encoders
# ---------------------------------------------------------------------------
MODEL_PATH = 'ssl_classifier_model.joblib'
joblib.dump({'model': best_model, 'encoders': encoders, 'feature_cols': list(X.columns)}, MODEL_PATH)
print(f"\nModel saved to {MODEL_PATH}")

# ---------------------------------------------------------------------------
# 6. Detailed classification report on a held-out split
# ---------------------------------------------------------------------------
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)
best_model.fit(X_train, y_train)
y_pred = best_model.predict(X_test)
y_prob = best_model.predict_proba(X_test)[:, 1]

print(f"\n{'=' * 60}")
print("HELD-OUT TEST SET REPORT (80/20 split)")
print("=" * 60)
print(classification_report(y_test, y_pred, target_names=['Legitimate (0)', 'Impersonation (1)']))
print(f"ROC-AUC: {roc_auc_score(y_test, y_prob):.3f}")
print("\nConfusion Matrix (rows=actual, cols=predicted):")
cm = confusion_matrix(y_test, y_pred)
cm_df = pd.DataFrame(cm,
    index=['Actual: Legitimate', 'Actual: Impersonation'],
    columns=['Pred: Legitimate', 'Pred: Impersonation']
)
print(cm_df)

# ---------------------------------------------------------------------------
# 6. Save plots
# ---------------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Feature importance plot
importances.head(15).plot(kind='barh', ax=axes[0], color='steelblue')
axes[0].set_title('Top 15 Feature Importances (Random Forest)')
axes[0].set_xlabel('Importance')
axes[0].invert_yaxis()

# Confusion matrix heatmap
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[1],
            xticklabels=['Legitimate', 'Impersonation'],
            yticklabels=['Legitimate', 'Impersonation'])
axes[1].set_title('Confusion Matrix (Test Set)')
axes[1].set_ylabel('Actual')
axes[1].set_xlabel('Predicted')

plt.tight_layout()
plt.savefig('ssl_classifier_results.png', dpi=150)
print("\nPlot saved to ssl_classifier_results.png")

# ---------------------------------------------------------------------------
# 7. Predict function for new certificates
# ---------------------------------------------------------------------------

def predict_certificate(
    subject_common_name: str,
    subject_org: str = 'N/A',
    subject_country: str = 'N/A',
    subject_state: str = 'N/A',
    subject_locality: str = 'N/A',
    issuer_cn: str = '',
    issuer_org: str = '',
    issuer_country: str = 'N/A',
) -> dict:
    """Predict whether a new SSL certificate is brand impersonation."""
    row = pd.DataFrame([{
        'Subject Common Name': subject_common_name,
        'Subject organization Name': subject_org,
        'Subject countryName': subject_country,
        'Subject state ProvinceName': subject_state,
        'Subject localityName': subject_locality,
        'Issuer Common Name': issuer_cn,
        'Issuer organization Name': issuer_org,
        'Issuer countryName': issuer_country,
    }])
    feats = extract_features(row)
    for col in cat_cols:
        le = encoders[col]
        val = feats[col].astype(str).iloc[0]
        if val in le.classes_:
            feats[col] = le.transform([val])
        else:
            feats[col] = -1  # unseen category
    saved = joblib.load(MODEL_PATH)
    prob = saved['model'].predict_proba(feats)[0][1]
    label = int(prob >= 0.5)
    return {
        'prediction': label,
        'label': 'Impersonation' if label == 1 else 'Legitimate',
        'confidence': f"{prob:.1%}",
    }


print("\n" + "=" * 60)
print("EXAMPLE PREDICTIONS")
print("=" * 60)

examples = [
    {
        'subject_common_name': 'fun-creators.net',
        'issuer_org': "Let's Encrypt",
        'issuer_country': 'US',
    },
    {
        'subject_common_name': 'outlook.com',
        'subject_org': 'Microsoft Corporation',
        'subject_country': 'US',
        'subject_state': 'Washington',
        'subject_locality': 'Redmond',
        'issuer_org': 'DigiCert Inc',
        'issuer_country': 'US',
    },
]

for ex in examples:
    result = predict_certificate(**ex)
    print(f"\n  Domain: {ex['subject_common_name']}")
    print(f"  Result: {result['label']} (confidence: {result['confidence']})")
